<?php
/**
 * Init Integrations
 *
 * @package StaticSnap
 */

namespace StaticSnap\Integrations;

use StaticSnap\Constants\Actions;

$integrations = array(
	Elementor::class,
	TranslatePress::class,
	InstaWP::class,

);


add_action(
	Actions::DEPLOYMENT_PROCESS_INIT_INTEGRATIONS,
	function () use ( $integrations ) {

		foreach ( $integrations as $integration ) {
			new $integration();
		}
	},
);
