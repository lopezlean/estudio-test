<?php
/**
 * All widgets
 *
 * @package StaticSnap
 */

namespace StaticSnap\Integrations\Elementor\Widgets;

/**
 * All widgets
 */
abstract class All_Widgets {

	public const ALL = array(
		Search_Widget::class,
	);
}
