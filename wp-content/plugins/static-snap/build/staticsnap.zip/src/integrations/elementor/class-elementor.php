<?php
/**
 * Class Elementor
 *
 * @package StaticSnap
 */

namespace StaticSnap\Integrations;

use StaticSnap\Frontend\Frontend;
use StaticSnap\Integrations\Elementor\Widgets\All_Widgets;

/**
 * Elementor class
 */
final class Elementor {

	/**
	 * Constructor
	 */
	public function __construct() {
		if ( class_exists( '\Elementor\Plugin' ) ) {
			add_action( 'elementor/frontend/before_enqueue_scripts', array( $this, 'replace_elementor_settings_urls' ), 10 );
			add_action( 'elementor/elements/categories_registered', array( $this, 'add_elementor_widget_categories' ) );
			add_action( 'elementor/widgets/widgets_registered', array( $this, 'register_widgets' ) );
		}
	}

	/**
	 * Replace Elementor settings URLs
	 */
	public function replace_elementor_settings_urls() {
		if ( ! Frontend::is_static() ) {
			return;
		}

		// get elmementor App.
		$elementor = \Elementor\Frontend::instance();

		// get settings.
		$settings = $elementor->get_settings();

		$urls = $settings['urls'];
		// convert url to relative, remove domain part.
		$urls = array_map(
			function ( $url ) {
				$url_parts = wp_parse_url( $url );

				return $url_parts['path'];
			},
			$urls
		);

		// set the new urls.
		$elementor->set_settings( 'urls', $urls );

		// elementor pro assets url filter.
		add_filter(
			'elementor_pro/frontend/assets_url',
			function ( $assets_url ) {
				$url_parts = wp_parse_url( $assets_url );
				return $url_parts['path'];
			}
		);
	}

	/**
	 * Add Elementor widget categories
	 */
	public function add_elementor_widget_categories() {
		\Elementor\Plugin::instance()->elements_manager->add_category(
			'static-snap',
			array(
				'title' => 'Static Snap',
				'icon'  => 'fa fa-plug',
			)
		);
	}

	/**
	 * Register widgets
	 */
	public function register_widgets() {

		foreach ( All_Widgets::ALL as $widget ) {
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new $widget() );
		}
	}
}
