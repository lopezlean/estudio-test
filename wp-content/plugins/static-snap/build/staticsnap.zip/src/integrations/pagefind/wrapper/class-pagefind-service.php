<?php
/**
 * Handles interactions with the Pagefind service.
 *
 * @package StaticSnap
 */

namespace StaticSnap\Integrations\Pagefind\Wrapper;

require_once __DIR__ . '/resolve-binary-path.php';

/**
 * Represents the Pagefind service, facilitating communication and data exchange.
 */
final class Pagefind_Service {
	/**
	 * The backend process handle.
	 *
	 * @var resource
	 */
	private $backend;

	/**
	 * A list of callbacks awaiting response.
	 *
	 * @var callable[]
	 */
	private $callbacks = array();

	/**
	 * The next message ID to be used.
	 *
	 * @var int
	 */
	private $message_id = 0;

	/**
	 * Buffer for incoming messages.
	 *
	 * @var string
	 */
	private $incoming_message_buffer = '';

	/**
	 * Pipes for interacting with the backend process.
	 *
	 * @var array
	 */
	private $backend_pipes = array();

	/**
	 * Initializes the Pagefind service by starting the backend process.
	 *
	 * @throws \Exception If the backend process fails to start.
	 */
	public function __construct() {
		$binary_path = resolve_binary_path( array( 'pagefind_extended', 'pagefind' ) );

		$descriptor_spec = array(
			array( 'pipe', 'r' ), // stdin is a pipe that the child will read from.
			array( 'pipe', 'w' ), // stdout is a pipe that the child will write to.
			array( 'pipe', 'w' ), // stderr is a pipe that the child will write to.
		);

		// phpcs:ignore	WordPress.PHP.DiscouragedPHPFunctions.system_calls_proc_open
		$this->backend = proc_open( $binary_path . ' --service', $descriptor_spec, $pipes, getcwd(), null, array( 'bypass_shell' => true ) );

		if ( is_resource( $this->backend ) ) {
			stream_set_blocking( $pipes[0], false );
			stream_set_blocking( $pipes[1], false );
			stream_set_blocking( $pipes[2], false );
			$this->backend_pipes = $pipes;
			register_tick_function( array( $this, 'check_incoming_messages' ) );
		} else {
			throw new \Exception( 'Failed to start backend process.' );
		}
	}

	/**
	 * Cleans up the backend process upon destruction.
	 */
	public function __destruct() {
		$this->close();
	}

	/**
	 * Closes the backend process and cleans up resources.
	 *
	 * @param \Exception|null $err Optional. The error that caused the service to close, if any.
	 */
	public function close( $err = null ) {
		if ( $err ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( 'Service stopped: ' . $err->getMessage() );
		}

		if ( is_resource( $this->backend ) ) {
			// this will never happen in php but it is just to mantain compatibility with the original code.
			foreach ( $this->callbacks as $cb ) {
				$cb(
					array(
						'exception' => 'Pagefind backend closed',
						'err'       => null,
						'result'    => null,
					)
				);
			}
			// phpcs:ignore
			fclose( $this->backend_pipes[0] ); // stdin.
			// phpcs:ignore
			fclose( $this->backend_pipes[1] ); // stdout.
			proc_terminate( $this->backend );
			$this->backend = null;
		}
	}
	/**
	 * Waits for all responses to be received.
	 */
	public function wait_for_responses() {
		while ( ! empty( $this->callbacks ) ) {
			$this->check_incoming_messages();
		}
	}

	/**
	 * Sends a message to the Pagefind backend and registers a callback for the response.
	 *
	 * @param array    $message  The message to send.
	 * @param callable $callback The callback to execute upon receiving a response.
	 * @throws \Exception If the backend is closed.
	 */
	public function send_message( $message, callable $callback ) {
		// phpcs:ignore
		if ( $this->backend === null ) {
			throw new \Exception( 'Cannot send message, backend is closed.' );
		}

		$wrapped_message = $this->wrap_outgoing_message( $message, $callback );
		$encoded         = self::encode_message( $wrapped_message );
		// phpcs:ignore
		fwrite( $this->backend_pipes[0], $encoded );

		$this->wait_for_responses();
	}

	/**
	 * Wraps a message and its associated callback for sending.
	 *
	 * @param array    $message  The message to wrap.
	 * @param callable $callback The callback associated with the message.
	 * @return array The wrapped message.
	 */
	private function wrap_outgoing_message( $message, callable $callback ) {
			$output_message = array(
				'message_id' => ++$this->message_id,
				'payload'    => $message,
			);

			$this->callbacks[ $output_message['message_id'] ] = $callback;
			return $output_message;
	}

	/**
	 * Checks for incoming messages and processes them.
	 */
	public function check_incoming_messages() {
		$read   = array( $this->backend_pipes[1] ); // stdout.
		$write  = null;
		$except = null;

		if ( stream_select( $read, $write, $except, 0 ) ) {
			// phpcs:ignore
			$data = fread( $this->backend_pipes[1], 8192 );
			$this->handle_incoming_chunk( $data );
		}
	}

	/**
	 * Handles a chunk of incoming data.
	 *
	 * @param string $buf The data buffer to process.
	 */
	private function handle_incoming_chunk( $buf ) {
		$this->incoming_message_buffer .= $buf;

		while ( ! empty( strval( $this->incoming_message_buffer ) ) && false !== strpos( $this->incoming_message_buffer, ',' ) ) {
			list( $message, $remaining ) = explode( ',', $this->incoming_message_buffer, 2 );
			$this->handle_incoming_message( $message );
			$this->incoming_message_buffer = $remaining;
		}
	}

	/**
	 * Processes an incoming message.
	 *
	 * @param string $message The message to process.
	 * @throws \Exception If the message is malformed or missing a message ID.
	 */
	private function handle_incoming_message( $message ) {
		$parsed_message = self::parse_message( $message );

		if ( $parsed_message && isset( $parsed_message['message_id'] ) ) {
			$message_id = $parsed_message['message_id'];

			if ( isset( $this->callbacks[ $message_id ] ) ) {
				$callback = $this->callbacks[ $message_id ];
				unset( $this->callbacks[ $message_id ] );

				$is_error          = isset( $parsed_message['payload']['type'] ) && 'Error' === $parsed_message['payload']['type'];
				$response_callback = array(
					'exception' => null,
					'err'       => $is_error ? $parsed_message['payload'] : null,
					'result'    => ! $is_error ? $parsed_message['payload'] : null,
				);

				call_user_func( $callback, $response_callback );
			}
		} else {
			throw new \Exception( 'Received message with unknown or missing message ID.' );
		}
	}

	/**
	 * Encodes a message for sending.
	 *
	 * @param array $message The message to encode.
	 * @return string The encoded message.
	 */
	private static function encode_message( $message ) {
		// phpcs:ignore
		return base64_encode( json_encode( $message ) ) . ',';
	}

	/**
	 * Decodes a received message using base64_decode() for benign reasons.
	 *
	 * @param string $message The message to decode.
	 * @return array The decoded message.
	 * @throws \Exception If the message cannot be parsed.
	 */
	private static function parse_message( $message ) {
		// phpcs:ignore
		$data = base64_decode( $message );

		$result = json_decode( $data, true );
		if ( null === $result ) {
			throw new \Exception( 'Failed to parse a message from the Pagefind service backend' );
		}

		return $result;
	}
}
