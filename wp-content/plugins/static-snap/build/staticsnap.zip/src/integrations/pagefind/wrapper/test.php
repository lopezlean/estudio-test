<?php
/**
 * Test the Wrapper
 *
 * @package StaticSnap
 */

?>
<?php

require_once __DIR__ . '/class-pagefind.php';
require_once __DIR__ . '/class-pagefind-service.php';
require_once __DIR__ . '/class-pagefind-index.php';



use StaticSnap\Integrations\Pagefind\Wrapper\Pagefind;


$pagefind = new PageFind();


$index = $pagefind->create_index();
if ( ! $index ) {
	echo 'Failed to create index';
	exit;
}

$directory  = $index->add_directory(
	array(
		'path' => '/var/www/html/pagefind/',
	)
);
$directory2 = $index->add_directory(
	array(
		'path' => '/var/www/html/wp-content/uploads/static-snap/tmp/',
	)
);
$record     = $index->add_html_file(
	array(
		'sourcePath' => 'resume2.html',
		'content'    => "<html lang='en'><body> <h1>Another A Full HTML Document</h1> <p> lopezlean </p> </body></html>",

	)
);

$files = $index->get_files();

$index->write_files( array( 'outputPath' => '/var/www/html/pagefind/' ) );
