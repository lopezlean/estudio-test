<?php
/**
 * Pagefind Rest
 *
 * @package StaticSnap
 */

namespace StaticSnap\Integrations\Pagefind\Rest;

/**
 * Pagefind Rest class
 * endpoint for pagefind: https://pagefind.vercel.app
 */
final class Pagefind_Rest_Client {
	/**
	 * The endpoint
	 *
	 * @var string
	 * Local docker endpoint: 'http://host.docker.internal:3000'
	 */

	private $endpoint = 'https://pagefind.vercel.app';

	/**
	 * Constructor
	 */
	public function __construct() {
	}


	/**
	 * Create pagefind index
	 *
	 * @return array
	 */
	public function create_index() {
		$endpoint = $this->endpoint . '/index';
		$response = wp_remote_post(
			$endpoint,
			array(
				'headers' => array(
					'Content-Type' => 'application/json',
				),
			)
		);
		// get json body.
		$body = wp_remote_retrieve_body( $response );
		// decode json.
		$data = json_decode( $body, true );
		return $data;
	}

	/**
	 * Add html file
	 *
	 * @param string $source_path The source path.
	 * @param string $content The content.
	 * @return array
	 */
	public function add_html_file( $source_path, $content ) {

		$endpoint = $this->endpoint . '/index/add/html';
		$body     = \gzencode(
			wp_json_encode(
				array(
					'sourcePath' => $source_path,
					'content'    => $content,
				)
			)
		);

		$response = wp_remote_post(
			$endpoint,
			array(
				'headers' => array(
					'Content-Type'     => 'application/json',
					'Content-Encoding' => 'gzip',
				),
				'body'    => $body,
			)
		);
		// get json body.
		$body = wp_remote_retrieve_body( $response );

		// decode json.
		$data = json_decode( $body, true );
		return $data;
	}

	/**
	 * Add Custom record
	 *
	 * @param string $source_path The source path.
	 * @param string $content The content.
	 * @param string $language The language.
	 * @param array  $meta The meta.
	 * @param array  $filters The filters.
	 * @param array  $sort The sort weight.
	 *
	 * @return array
	 */
	public function add_custom_record( $source_path, $content, $language = null, $meta = array(), $filters = array(), $sort = array() ) {
		$endpoint = $this->endpoint . '/index/add/custom';
		$body     = \gzencode(
			wp_json_encode(
				array(
					'sourcePath' => $source_path,
					'content'    => $content,
					'language'   => $language,
					'meta'       => $meta,
					'filters'    => $filters,
					'sort'       => $sort,
				)
			)
		);
		$response = wp_remote_post(
			$endpoint,
			array(
				'headers' => array(
					'Content-Type'     => 'application/json',
					'Content-Encoding' => 'gzip',
				),
				'body'    => $body,
			)
		);
		// get json body.
		$body = wp_remote_retrieve_body( $response );
		// decode json.
		$data = json_decode( $body, true );
		return $data;
	}

	/**
	 * Download index
	 *
	 * @return array
	 */
	public function download_index() {
		$endpoint = $this->endpoint . '/index/download';
		$response = wp_remote_post(
			$endpoint,
			array(
				'headers' => array(
					'Content-Type' => 'application/json',
				),
			)
		);
		// get json body.
		$body = wp_remote_retrieve_body( $response );
		// decode json.
		$data = json_decode( $body, true );

		return $data;
	}
}
