<?php
/**
 * Handles Pagefind functionality within StaticSnap.
 *
 * @package StaticSnap\Integrations\Pagefind\Wrapper
 */

namespace StaticSnap\Integrations\Pagefind\Wrapper;

/**
 * Pagefind class for managing Pagefind services.
 */
final class Pagefind {
	/**
	 * Holds the persistent service instance.
	 *
	 * @var Pagefind_Service|null
	 */
	private static $persistent_service = null;

	/**
	 * Launches the Pagefind service if not already running.
	 *
	 * @return Pagefind_Service The Pagefind service instance.
	 */
	public static function launch() {
		if ( null === self::$persistent_service ) {
			self::$persistent_service = new Pagefind_Service();
		}
		return self::$persistent_service;
	}


	/**
	 * Creates a new index with the given configuration.
	 *
	 * @param array $config The configuration for the new index.
	 * @return mixed The index creation result.
	 */
	public static function create_index( $config = array() ) {
		$service = self::launch();
		$action  = 'NewIndex';
		$index   = null;

		$callback = function ( $response ) use ( $action, &$index ) {
			$success_callback = function ( $success ) use ( $action, &$index ) {
				if ( $success['type'] !== $action ) {
					// phpcs:ignore
					throw new \Exception( "Message returned from backend should have been {$action}, but was {$success['type']}" );
				}

				$index = self::index_fns( $success['index_id'] );
			};

			return self::handle_api_response( $response, $success_callback );
		};

		$service->send_message(
			array(
				'type'   => $action,
				'config' => array(
					'root_selector'     => $config['rootSelector'] ?? null,
					'exclude_selectors' => $config['excludeSelectors'] ?? null,
					'force_language'    => $config['forceLanguage'] ?? null,
					'verbose'           => $config['verbose'] ?? null,
					'logfile'           => $config['logfile'] ?? null,
					'keep_index_url'    => $config['keepIndexUrl'] ?? null,
				),
			),
			$callback
		);

		return $index;
	}

	/**
	 * Closes the persistent service and cleans up resources.
	 */
	public static function close() {
		if ( null !== self::$persistent_service ) {
			self::$persistent_service->close();
			self::$persistent_service = null;
		}
	}

	/**
	 * Handles the API response.
	 *
	 * @param array    $response The API response.
	 * @param callable $result_fn The function to process the result.
	 * @return mixed The processed response result.
	 * @throws \Exception If the response contains an exception.
	 */
	private static function handle_api_response( $response, callable $result_fn ) {
		if ( isset( $response['exception'] ) ) {
			// phpcs:ignore
			throw new \Exception( $response['exception'] );
		} else {
			return $result_fn( $response['result'] );
		}
	}

	/**
	 * Placeholder for index functionalities, needs to be implemented.
	 *
	 * @param int $index_id The index ID.
	 * @return Pagefind_Index The Pagefind index instance.
	 */
	private static function index_fns( $index_id ) {
		return new Pagefind_Index( $index_id, self::launch() ); // Assuming PagefindIndex implementation.
	}
}
