<?php
/**
 * Page find search type
 *
 * @package StaticSnap
 */

namespace StaticSnap\Integrations;

use StaticSnap\Constants\Actions;
use StaticSnap\Extension\Extension_Base;

/**
 * Pagefind search type
 */
final class Pagefind_Search_Extension extends Extension_Base {

	/**
	 * Get type
	 *
	 * Extension type
	 * Valids: 'search', 'environment_type'
	 *
	 * @return string
	 */
	public function get_type(): string {
		return 'search';
	}

	/**
	 * Get name.
	 *
	 * @return string
	 */
	public function get_name(): string {
		return 'pagefind';
	}

	/**
	 * Get settings fields
	 *
	 * @return array of settings fields name => field definition
	 */
	public function get_settings_fields(): array {
		return array(
			'api_key' => array(
				'required'   => true,
				'type'       => 'textarea',
				'label'      => 'API Key',
				'helperText' => 'The API key for the Pagefind search service.',
			),
			'api_secret' => array(
				'required'   => true,
				'type'       => 'html',
				'label'      => 'API Secret',
				'helperText' => 'The API secret for the Pagefind search service.',
			),
		);
	}

	/**
	 * Test if pagefind is configured correctly
	 */
	public function is_configured(): bool {
		return true;
	}
}
