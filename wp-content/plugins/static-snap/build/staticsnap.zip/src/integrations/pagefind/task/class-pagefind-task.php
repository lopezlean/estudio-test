<?php
/**
 * Pagefind Task
 *
 * @package StaticSnap
 */

namespace StaticSnap\Integrations\Pagefind\Task;

use StaticSnap\Database\URLS_Database;
use StaticSnap\Deployment\Post_URL;
use StaticSnap\Deployment\Task;
use StaticSnap\Integrations\Pagefind\Rest\Pagefind_Rest_Client;
use StaticSnap\Integrations\Pagefind\Wrapper\Pagefind;


/**
 * Pagefind Task class
 * Just to start the task
 */
final class Pagefind_Task extends Task {
	/**
	 * Task name
	 *
	 * @var string
	 */
	protected $description = 'Building Pagefind Index';

	/**
	 * Force rest API
	 *
	 * @var bool
	 */
	protected $force_rest = true;

	/**
	 * Perform task
	 *
	 * Override this method to perform any actions required on each
	 * queue item. Return the modified item for further processing
	 * in the next pass through. Or, return false to remove the
	 * item from the queue.
	 *
	 * @return bool
	 */
	public function perform(): bool {
		// Check if proc_open is enabled.
		if ( ! function_exists( 'proc_open' ) || $this->force_rest ) {
			return $this->perform_rest();
		}

		return $this->perform_internally();
	}
	/**
	 * Perform rest
	 *
	 * @return bool
	 */
	protected function perform_rest() {
		$pagefind = new Pagefind_Rest_Client();
		$response = $pagefind->create_index();

		// get all urls database.
		$urls = URLS_Database::instance()->get_all( 'indexed' );
		while ( $urls ) {
			foreach ( $urls as $url ) {
				$local_destination = $url->local_path_destination;
				// read the file using wp file system.
				global $wp_filesystem;

				if ( ! $wp_filesystem ) {
					require_once ABSPATH . 'wp-admin/includes/file.php';
					WP_Filesystem();
				}

				try {
					$contents = $wp_filesystem->get_contents( $local_destination );
				} catch ( \Exception $e ) {
					URLS_Database::instance()->set_indexed( $url->id );
					continue;
				}
				if ( ! $contents ) {
					URLS_Database::instance()->set_indexed( $url->id );
					continue;
				}

				$response = $pagefind->add_html_file(
					$url->url,
					$contents
				);

				if ( ! $response ) {
					URLS_Database::instance()->set_indexed( $url->id );
					continue;
				}
				URLS_Database::instance()->set_indexed( $url->id );

			}

			$urls = URLS_Database::instance()->get_all( 'indexed' );
		}

		$downloaded_index = $pagefind->download_index();

		return true;
	}


	/**
	 * Perform internally
	 *
	 * @return bool
	 */
	protected function perform_internally() {
		$directory = wp_upload_dir()['basedir'] . DIRECTORY_SEPARATOR . 'static-snap' . DIRECTORY_SEPARATOR . 'tmp';
		$pagefind  = new Pagefind();
		$index     = $pagefind->create_index();

		if ( ! $index ) {
			return false;
		}

		$index->add_directory(
			array(
				'path' => $directory,
			)
		);

		$index->get_files();

		$index->write_files( array( 'outputPath' => $directory . '/pagefind' ) );

		return true;
	}
}
