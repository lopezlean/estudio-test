<?php
/**
 * Pagefind integration
 *
 * @package StaticSnap
 */

namespace StaticSnap\Integrations;

use StaticSnap\Constants\Filters;
use StaticSnap\Deployment\Deployment_Task_Manager;
use StaticSnap\Integrations\Pagefind\Task\Pagefind_Task;

/**
 * Pagefind class
 */
final class Pagefind {

	/**
	 * Constructor
	 */
	public function __construct() {

		add_filter( Filters::DEPLOYMENT_TASKS, array( $this, 'add_pagefind_task' ), 10 );
		new Pagefind_Search_Extension();
		// filter post_content for ID 828.
		add_filter( 'the_content', array( $this, 'filter_post_content' ), 10, 1 );

		add_filter( 'wp_script_attributes', array( $this, 'add_type_attribute' ), 10, 1 );

		// enqueue scripts for post ID 828.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 10 );
		// enqueue css for post ID 828.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_css' ), 10 );
	}

	/**
	 * Add Pagefind task
	 *
	 * @param array $tasks The array of tasks.
	 * @return array
	 */
	public function add_pagefind_task( $tasks ) {
		// insert before zip task.
		$zip_task_index = array_search( Deployment_Task_Manager::ZIP_TASK, $tasks, true );
		if ( false !== $zip_task_index ) {
			array_splice( $tasks, $zip_task_index, 0, Pagefind_Task::class );
		} else {
			$tasks[] = Pagefind_Task::class;
		}

		return $tasks;
	}
	/**
	 * Filter post content
	 *
	 * @param string $content The content.
	 * @return string
	 */
	public function filter_post_content( $content ) {
		// get current post id.
		$post_id = get_the_ID();
		// filter post_content for ID 828.
		if ( 828 === $post_id ) {
			$content = str_replace( 'Lorem', 'Pagefind', $content );

		}
		return $content;
	}

	/**
	 * Enqueue scripts
	 *
	 * @return void
	 */
	public function enqueue_scripts() {

		// get current post id.
		$post_id = get_the_ID();
		// enqueue scripts for post ID 828.
		if ( 828 === $post_id ) {
			wp_enqueue_script( 'pagefind', '/wp-content/uploads/static-snap/tmp/stage/pagefind/pagefind-ui.js', array(), '1.0.0', true );
			wp_enqueue_script( 'pagefind-handler', '/wp-content/plugins/static-snap/src/integrations/pagefind/js/pagefind.js', array(), '1.0.0', true );
		}
	}
	/**
	 * Enqueue css
	 *
	 * @return void
	 */
	public function enqueue_css() {
		// get current post id.
		$post_id = get_the_ID();
		// enqueue css for post ID 828.
		if ( 828 === $post_id ) {
			wp_enqueue_style( 'pagefind', '/wp-content/uploads/static-snap/tmp/stage/pagefind/pagefind-ui.css', array(), '1.0.0' );
		}
	}

	/**
	 * Add type attribute
	 *
	 * @param array $attributes The tag.
	 * @return array
	 */
	public function add_type_attribute( array $attributes ): array {

		// Only do this for a specific script.
		if ( isset( $attributes['id'] ) && 'pagefind-js' === $attributes['id'] ) {
			$attributes['type'] = 'module';
		}

		return $attributes;
	}
}
