#!/usr/bin/env php
<?php
/**
 * A command-line script to run the Pagefind executable with arguments.
 *
 * This script acts as a PHP wrapper for running the Pagefind executable,
 * supporting verbose output based on provided arguments.
 *
 * @package StaticSnap
 */

// Include the function to resolve the binary path of Pagefind executables.
require_once __DIR__ . '/resolve-binary-path.php';

// Define the executable names.
$exec_name  = 'pagefind';
$exec_names = array( 'pagefind_extended', 'pagefind' );

// Capture command-line arguments, excluding the script name.
$args = array_slice( $argv, 1 );

// Resolve the binary path using the defined executable names.
$binary_path = resolve_binary_path( $exec_names );

// Flag for verbose output, determined by the presence of verbose-related arguments.
$verbose = false;
foreach ( $args as $arg ) {
	if ( preg_match( '/verbose|-v$/', $arg ) ) {
		$verbose = true;
	}
}

// If verbose mode is enabled, print the executable path.
if ( $verbose ) {
	// phpcs:ignore
	echo "{$exec_name} PHP wrapper: Running the executable at {$binary_path}\n";
}

// Execute the binary with the provided arguments.
$output     = array();
$return_var = 0;
// phpcs:ignore
exec( "{$binary_path} " . implode( ' ', array_map( 'escapeshellarg', $args ) ), $output, $return_var );

// If verbose mode is enabled, print the process exit status.
if ( $verbose ) {
	// phpcs:ignore
	echo "{$exec_name} PHP wrapper: Process exited with status {$return_var}\n";
}

// Print each line of output from the executable.
foreach ( $output as $line ) {
	// phpcs:ignore
	echo $line . PHP_EOL;
}

// Exit with the status code returned by the executable.
// phpcs:ignore
exit( $return_var );
