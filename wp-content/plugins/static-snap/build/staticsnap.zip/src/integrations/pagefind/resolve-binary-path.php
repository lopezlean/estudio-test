<?php
/**
 * Resolve the binary path for given executables.
 *
 * @param array $execnames Array of executable names.
 * @return string The resolved binary path.
 * @throws Exception If the binary path cannot be resolved.
 * @package StaticSnap
 */

?>
<?php
/**
 * Resolve the binary path for given executables.
 *
 * @param array $execnames Array of executable names.
 * @return string The resolved binary path.
 * @throws Exception If the binary path cannot be resolved.
 */
function resolve_binary_path( array $execnames = array() ) {
	foreach ( $execnames as $execname ) {
		$env_var = getenv( strtoupper( $execname ) . '_BINARY_PATH' );
		if ( $env_var ) {
			return $env_var;
		}
	}

	$cpu      = php_uname( 'm' );
	$platform = strtolower( php_uname( 's' ) );
	$platform = 'windows nt' === $platform ? 'windows' : $platform;

	foreach ( $execnames as $execname ) {
		$executable = 'windows' === $platform ? $execname . '.exe' : $execname;
		$path       = __DIR__ . "/bin/$platform/$cpu/$executable";

		// Attempt to check if the file exists. Note: This part is simplified as PHP does not directly support package-based resolution like Node.js.
		// You may need to adjust the path according to where your PHP script is expected to find these binaries.
		if ( file_exists( $path ) ) {
			return realpath( $path );
		}
	}

	throw new Exception(
		// phpcs:ignore
		'Failed to install either of [' . implode( ', ', $execnames ) . "]. Most likely the platform $platform-$cpu is not yet a supported architecture.\n" .
		"Please open an issue at https://github.com/CloudCannon/pagefind and paste this error message in full.\n" .
		'If you believe this package should be compatible with your system, ' .
		'you can try downloading a release binary directly from https://github.com/CloudCannon/pagefind/releases'
	);
}


try {
	$binary_path = resolve_binary_path( array( 'pagefind', 'pagefind_extended' ) );
	// phpcs:ignore
	echo 'Resolved binary path: ' . $binary_path . "\n";
} catch ( Exception $e ) {
	// phpcs:ignore
	echo 'Error: ' . $e->getMessage() . "\n";
}
