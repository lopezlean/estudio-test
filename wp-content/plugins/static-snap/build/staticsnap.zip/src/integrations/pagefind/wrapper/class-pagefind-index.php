<?php
/**
 * Manages a single index within the Pagefind integration.
 *
 * @package StaticSnap\Integrations\Pagefind\Wrapper
 */

namespace StaticSnap\Integrations\Pagefind\Wrapper;

/**
 * Pagefind Index class for handling index-specific operations.
 */
final class Pagefind_Index {

	/**
	 * The ID of the index.
	 *
	 * @var int
	 */
	private $index_id;

	/**
	 * The Pagefind service instance.
	 *
	 * @var Pagefind_Service
	 */
	private $service;

	/**
	 * Initializes the Pagefind_Index instance.
	 *
	 * @param int              $index_id The index ID.
	 * @param Pagefind_Service $service  The Pagefind service instance.
	 */
	public function __construct( $index_id, $service ) {
		$this->index_id = $index_id;
		$this->service  = $service;
	}

	/**
	 * Adds an HTML file to the index.
	 *
	 * @param array $file The file to add.
	 * @return array The response from the API after adding the file.
	 */
	public function add_html_file( $file ) {
		$action          = 'AddFile';
		$response_action = 'IndexedFile';
		$r               = null;
		$this->service->send_message(
			array(
				'type'          => $action,
				'index_id'      => $this->index_id,
				'file_path'     => $file['sourcePath'],
				'url'           => $file['url'],
				'file_contents' => $file['content'],
			),
			function ( $response ) use ( &$r ) {
				$r = $response['result'];
			}
		);

		return $this->handle_api_response( $r, $response_action );
	}

	/**
	 * Adds a custom record to the index.
	 *
	 * @param array $record The record to add.
	 * @return array The response from the API after adding the custom record.
	 */
	public function add_custom_record( $record ) {
		$action          = 'AddRecord';
		$response_action = 'IndexedFile';
		$r               = null;
		$this->service->send_message(
			array(
				'type'     => $action,
				'index_id' => $this->index_id,
				'url'      => $record['url'],
				'content'  => $record['content'],
				'language' => $record['language'],
				'meta'     => $record['meta'],
				'filters'  => $record['filters'],
				'sort'     => $record['sort'],
			),
			function ( $response ) use ( &$r ) {
				$r = $response['result'];
			}
		);

		return $this->handle_api_response( $r, $response_action );
	}

	/**
	 * Adds a directory to the index.
	 *
	 * @param array $dir The directory to add.
	 * @return array The response from the API after adding the directory.
	 */
	public function add_directory( $dir ) {
		$action          = 'AddDir';
		$response_action = 'IndexedDir';

		$r = null;
		$this->service->send_message(
			array(
				'type'     => $action,
				'index_id' => $this->index_id,
				'path'     => $dir['path'],
				'glob'     => $dir['glob'],
			),
			function ( $response ) use ( &$r ) {
				$r = $response['result'];
			}
		);

		return $this->handle_api_response( $r, $response_action );
	}

	/**
	 * Writes files to the index based on provided options.
	 *
	 * @param array $options Options for writing files.
	 * @return array The response from the API after writing the files.
	 */
	public function write_files( $options ) {
		$action = 'WriteFiles';
		$r      = null;
		$this->service->send_message(
			array(
				'type'        => $action,
				'index_id'    => $this->index_id,
				'output_path' => $options['outputPath'] ?? null,
			),
			function ( $response ) use ( &$r ) {
				$r = $response['result'];
			}
		);

		return $this->handle_api_response( $r, $action );
	}

	/**
	 * Retrieves files from the index.
	 *
	 * @return array The files retrieved from the index.
	 */
	public function get_files() {
		$action = 'GetFiles';
		$r      = null;$this->service->send_message(
			array(
				'type'     => $action,
				'index_id' => $this->index_id,
			),
			function ( $response ) use ( &$r ) {
				$r = $response['result'];
			}
		);

		return $this->handle_api_response( $r, $action );
	}

	/**
	 * Deletes the index.
	 *
	 * @return array The response from the API after deleting the index.
	 */
	public function delete_index() {
		$action = 'DeleteIndex';
		$r      = null;$this->service->send_message(
			array(
				'type'     => $action,
				'index_id' => $this->index_id,
			),
			function ( $response ) use ( &$r ) {
				$r = $response['result'];
			}
		);

		return $this->handle_api_response( $r, $action );
	}

	/**
	 * Handles the response from the API.
	 *
	 * @param array  $response The response to handle.
	 * @param string $action   The action for which the response is expected.
	 * @return array The handled response.
	 * @throws \Exception If the response cannot be processed.
	 */
	private function handle_api_response( $response, $action ) {
		if ( isset( $response['type'] ) && $response['type'] === $action ) {
			return $response;
		} else {
			// phpcs:ignore
			throw new \Exception( sprintf("Error processing response for action {$action}") );
		}
	}
}
