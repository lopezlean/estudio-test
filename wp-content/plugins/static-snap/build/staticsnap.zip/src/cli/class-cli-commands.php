<?php
/**
 * Cli Commands
 *
 * @package StaticSnap
 */

namespace StaticSnap\Cli;

use StaticSnap\Deployment\Deployment_Process;
use StaticSnap\Application;

use WP_CLI;

use function Clue\StreamFilter\register;

/**
 * Cli Commands
 */
final class Cli_Commands {

	/**
	 * Deployment
	 *
	 * @var Deployment_Process $deployment
	 */
	protected $deployment = null;

	/**
	 * Constructor
	 */
	public function __construct() {
		$app              = Application::instance();
		$this->deployment = $app->get_deployment();
		$this->register_commands();
	}

	/**
	 * Register commands
	 *
	 * @return void
	 */
	public function register_commands(): void {
		WP_CLI::add_command( 'static-snap deploy', array( $this, 'deploy' ) );
		WP_CLI::add_command( 'static-snap cancel', array( $this, 'cancel' ) );
	}

	/**
	 * Deploy
	 *
	 * @param array $args Args.
	 * @return void
	 */
	public function deploy( array $args ): void {
		// get id from args.
		$name = (string) $args[0];
		$e    = \StaticSnap\Database\Environments_Database::instance()->get_by_name( $name );
		if ( ! $e ) {
			WP_CLI::error( 'Environment not found' );
			return;
		}
		$this->deployment->run_cli( $e );
	}

	/**
	 * Cancel
	 */
	public function cancel(): void {
		$this->deployment->cancel();
	}
}
