<?php
/**
 * Recaptcha Constants
 *
 * @package StaticSnap
 */

namespace StaticSnap\Constants;

/**
 * This class is used to define all the filters used in the plugin
 */
abstract class Recaptcha {
	const SITE_KEY = '6LcDGAEqAAAAABWdOUMCzsLNzdXJ5dUHgtbazeIN';
}
