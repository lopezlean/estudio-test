<?php
/**
 * Base class for Environments
 *
 * @package StaticSnap
 */

namespace StaticSnap\Environments;

use StaticSnap\Extension\Extension_Base;
use StaticSnap\Interfaces\Environment_Type_Interface;
use JsonSerializable;
use StaticSnap\Constants\Actions;

/**
 * This class is used to create the base environment.
 */
abstract class Environment_Type_Base extends Extension_Base implements Environment_Type_Interface, JsonSerializable {


	/**
	 * Needs Static Snap connect to be available
	 *
	 * @return boolean
	 */
	public function needs_connect(): bool {
		return false;
	}
	/**
	 * Needs zip file
	 *
	 * @return bool
	 */
	public function needs_zip(): bool {
		return false;
	}


	/**
	 * Json serialize
	 *
	 * @return array
	 */
	public function jsonSerialize(): array {
		return array(
			'name'         => $this->get_name(),
			'type'         => $this->get_type(),
			'available'    => $this->is_available(),
			'needsConnect' => $this->needs_connect(),
			'needsZip'     => $this->needs_zip(),
			'settings'     => $this->get_settings_fields(),
		);
	}



	/**
	 * Get type
	 *
	 * @return string
	 */
	public function get_type(): string {
		return 'environment_type';
	}

	/**
	 * Get name
	 *
	 * @return string
	 */
	abstract public function get_name(): string;
}
