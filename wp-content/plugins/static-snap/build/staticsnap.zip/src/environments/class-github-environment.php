<?php
/**
 * File Environment
 * This class is used to create the file environment.
 *
 * @package StaticSnap
 */

namespace StaticSnap\Environments;

use StaticSnap\Config\Options;
use StaticSnap\Environments\Environment_Type_Base;
use StaticSnap\Github\Github_Manager;


/**
 * This class is used to create the file environment.
 */
final class Github_Environment extends Environment_Type_Base {

	/**
	 * Is available
	 * It's require Connect and Github Static Snap App installed on the github account to be available
	 * Github App: https://github.com/apps/static-snap
	 *
	 * @return boolean
	 */
	public function is_available(): bool {
		// get connected option.
		$options = Options::instance()->get_options();
		if ( empty( $options['connect']['installation_id'] ) ) {
			return false;
		}
		return true;
	}
	/**
	 * Needs Static Snap connect to be available
	 *
	 * @return boolean
	 */
	public function needs_connect(): bool {
		return true;
	}

	/**
	 * Needs zip file
	 *
	 * @return bool
	 */
	public function needs_zip(): bool {
		return true;
	}

	/**
	 * Get name.
	 *
	 * @return string
	 */
	public function get_name(): string {
		return 'github';
	}

	/**
	 * Get settings fields
	 *
	 * @return array of settings fields name => field definition
	 * @example array
	 *  [
	 *      'api_key' => array( 'type' => 'text' ),
	 *      'api_secret' => array( 'type' => 'text' ),
	 *  ]
	 */
	public function get_settings_fields(): array {
		// repositories from GitHub_Manager.
		$repositories = array();
		$github       = new Github_Manager();
		$repos        = $github->get_user_repositories();

		foreach ( $repos['repositories'] as $repo ) {
			$repositories[] = array(
				'label' => $repo['full_name'],
				'value' => $repo['name'],
			);
		}
		return array(
			'repository' => array(
				'type'  => 'array',
				'label' => 'Repository',
				'items' => $repositories,
			),
			'branch' => array(
				'type'  => 'text',
				'label' => 'Branch',
			),

		);
	}

	/**
	 * Test if the environment is configured correctly
	 */
	public function is_configured(): bool {
		$settings = $this->get_settings();
		if ( empty( $settings['repository'] ) ) {
			$this->add_error( 'repository', 'Repository is required' );
		}
		if ( empty( $settings['branch'] ) ) {
			$this->add_error( 'branch', 'Branch is required' );
		}
		return empty( $this->errors );
	}
	/**
	 * This method is called when a build is published
	 *
	 * @param string $path path to the build.
	 * @return bool true if the build is published.
	 */
	public function on_publish( string $path ): bool {
		// TODO: Implement on_publish() method.
		return true;
	}

	/**
	 * Get deployment tasks
	 *
	 * @return array
	 */
	public function get_deployment_tasks(): array {
		return Github_Manager::get_deployment_tasks();
	}
}
