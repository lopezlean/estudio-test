<?php
/**
 * Github
 *
 * @package StaticSnap
 */

namespace StaticSnap\Github;

use StaticSnap\Application;
use StaticSnapVendor\Github\AuthMethod;
use StaticSnapVendor\Github\Client;

use StaticSnap\Cache\Cache_Persister;
use StaticSnap\Connect\Connect;


/**
 * Class to manage GitHub authentication and operate on repositories.
 */
final class Github_Manager extends Cache_Persister {
	/**
	 * Static snap connect
	 *
	 * @var array
	 */
	protected $connect;



	/**
	 * Uses the access token to obtain the user's repositories.
	 *
	 * @return array List of user's repositories.
	 * @throws \Exception If there is an error getting the repositories.
	 */
	public function get_user_repositories() {
		$connect      = Connect::instance();
		$connect_data = $connect->get_connect_data();

		if ( empty( $connect_data['installation_token'] ) ) {
			return array();
		}

		$installation_access_token = $connect_data['installation_token'];
		// fetch /api/forms/add.
		wp_remote_post(
			Application::instance()->get_static_snap_api_url( '/forms/add' ),
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $installation_access_token,
				),
			)
		);

		// get repositories from cache.
		$repositories = $this->get_cache();
		if ( ! empty( $repositories ) ) {
			return $repositories;
		}

		$client = new Client();
		$token  = $connect_data['installation_token'];

		try {
			$client->authenticate( $token, null, AuthMethod::ACCESS_TOKEN );
		} catch ( \Exception $e ) {
			throw new \Exception( 'Error authenticating : ' . esc_html( $e->getMessage() ) );

		}
		try {
			$repositories = $client->api( 'apps' )->listRepositories();
		} catch ( \Exception $e ) {
			$data = $connect->refresh_github_token();
			throw new \Exception( 'Error getting repositories : ' . esc_html( $e->getMessage() ) );
		}

		$this->set_cache( $repositories );

		return $repositories;
	}

	/**
	 * Upload action file to the repository.
	 * This file is used to deploy the site using Static Snap.
	 *
	 * @param string $repo  Repository name.
	 * @param string $branch Branch name.
	 * @throws \Exception If there is an error uploading the file.
	 * @return bool
	 */
	public function upload_action_file( $repo, $branch = 'main' ) {
		$connect      = Connect::instance();
		$connect_data = $connect->get_connect_data();
		if ( empty( $connect_data['installation_token'] ) ) {
			return false;
		}

		$client = new Client();
		$token  = $connect_data['installation_token'];
		$owner  = $connect_data['related_github_user']['github_login'];

		try {
			$client->authenticate( $token, null, AuthMethod::ACCESS_TOKEN );
		} catch ( \Exception $e ) {
			throw new \Exception( 'Error authenticating : ' . esc_html( $e->getMessage() ) );
		}

		$filename = '.github/workflows/static-snap-site-deploy.yml';

		ob_start();
		include __DIR__ . '/action/github-action-template.yml';
		$action_file_content = ob_get_clean();

		try {
			$contents = $client->api( 'repo' )->contents()->show( $owner, $repo, $filename, $branch );

			// phpcs:ignore
			$existing_content = base64_decode( $contents['content'] );

			if ( $existing_content === $action_file_content ) {
				// Contents are the same, no update needed.
				return true;
			}

			// Update the file since contents are different.
			$client->api( 'repo' )->contents()->update( $owner, $repo, $filename, $action_file_content, __( 'Update Static Snap action file', 'static-snap' ), $contents['sha'], $branch );

		} catch ( \Exception $e ) {
			if ( 404 === $e->getCode() ) {
				// File does not exist, create new.
				$client->api( 'repo' )->contents()->create( $owner, $repo, $filename, $action_file_content, __( 'Add Static Snap action file', 'static-snap' ), $branch );
			} else {
				throw new \Exception( 'Error accessing GitHub API: ' . esc_html( $e->getMessage() ) );
			}
		}

		return true;
	}

	/**
	 * Create release
	 * with a zip file
	 *
	 * @param string $repo Repository name.
	 * @param string $branch Branch name.
	 * @param string $zip_file Full path to the zip file.
	 * @throws \Exception If there is an error creating the release.
	 * @return bool
	 */
	public function create_release( $repo, $branch, $zip_file ) {
		$connect      = Connect::instance();
		$connect_data = $connect->get_connect_data();
		if ( empty( $connect_data['installation_token'] ) ) {
			return false;
		}

		$client = new Client();
		$token  = $connect_data['installation_token'];
		$owner  = $connect_data['related_github_user']['github_login'];

		$client->authenticate( $token, null, AuthMethod::ACCESS_TOKEN );

		/**
		 * Create a release
		 * with a zip file
		 */

		$tag_name = uniqid();
		// translators: %s is the branch name.
		$name = sprintf( __( 'Static Snap Release for branch %s', 'static-snap' ), $branch );
		$body = __( 'ZIP release from Static Snap.', 'static-snap' );

		$release = $client->api( 'repo' )->releases()->create(
			$owner,
			$repo,
			array(
				'tag_name'         => $tag_name,
				'target_commitish' => $branch,
				'name'             => $name,
				'body'             => $body,
				'draft'            => true,
				'prerelease'       => false,
			)
		);

		$release_id = $release['id'];

		// Upload asset using cURL.

		// Initialize GuzzleHttp Client.
		$guzzle_client = new \GuzzleHttp\Client();
		$upload_url    = str_replace( '{?name,label}', '?name=release.zip', $release['upload_url'] );

		try {
			$response = $guzzle_client->request(
				'POST',
				$upload_url,
				array(
					'headers' => array(
						'Authorization' => 'token ' . $token,
						'Content-Type'  => 'application/zip',
						'Accept'        => 'application/vnd.github.v3+json',
					),
					// phpcs:ignore
					'body'    => fopen( $zip_file, 'rb' ),
				)
			);
			$status_code = $response->getStatusCode();
			$body        = $response->getBody()->getContents();

			// Check if upload was successful.
			if ( 201 !== $status_code ) {
				// translators: %s is the status_code.
				throw new \Exception( sprintf( __( 'Failed to upload asset, status code: %s' ), $status_code ) );
			}
		} catch ( \Exception $e ) {
			return false;
		}

		$edit = $client->api( 'repo' )->releases()->edit(
			$owner,
			$repo,
			$release_id,
			array(
				'draft'      => false,
				'prerelease' => false,
			)
		);

		return true;
	}

	/**
	 * Get deployment tasks
	 *
	 * @return array
	 */
	public static function get_deployment_tasks(): array {
		return array(
			'StaticSnap\Github\Tasks\Upload_Action_File_Task',
			'StaticSnap\Github\Tasks\Create_Release_Task',
		);
	}
}
