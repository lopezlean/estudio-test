<?php
/**
 * Search templates
 *
 * @package StaticSnap
 */

namespace StaticSnap\Search;

use StaticSnap\Traits\Renderable;

/**
 * Search templates
 */
final class Search_Form_Template {


	use Renderable;
}
