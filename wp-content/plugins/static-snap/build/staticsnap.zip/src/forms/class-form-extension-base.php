<?php
/**
 * Forms base class
 *
 * @package StaticSnap
 */

namespace StaticSnap\Forms;

use StaticSnap\Constants\Filters;
use StaticSnap\Extension\Extension_Base;
use StaticSnap\Connect\Connect;
use StaticSnap\Application;
use StaticSnap\Config\Options;

/**
 * Base extension class for Forms
 */
abstract class Form_Extension_Base extends Extension_Base {


	/**
	 * Constructor
	 *
	 * @param array $params The parameters.
	 */
	public function __construct( $params = array() ) {
		parent::__construct( $params );
		// check if this filter is already added.
		if ( ! has_filter( Filters::SET_OPTIONS . '_forms', array( $this, 'on_set_options' ) ) ) {
			add_filter( Filters::SET_OPTIONS . '_forms', array( $this, 'on_set_options' ), 10, 1 );
		}
	}

	/**
	 * Get type
	 */
	public function get_type(): string {
		return 'form';
	}

	/**
	 * Get website token
	 *
	 * @return string
	 */
	public function get_website_token(): string {
		$connect      = Connect::instance();
		$connect_data = $connect->get_connect_data();
		return $connect_data['website_token'] ?? '';
	}

	/**
	 * Get action URL
	 *
	 * @return string
	 */
	public function get_action_url(): string {
		return Application::instance()->get_static_snap_api_url( '/forms/submit', 'frontend' );
	}

	/**
	 * Is configured
	 */
	public function is_configured(): bool {
		return true;
	}

	/**
	 * Get Settings fields
	 */
	public function get_settings_fields(): array {
		return array();
	}

	/**
	 * Get recaptcha site key
	 */
	public function get_recaptcha_site_key(): string {
		return Options::instance()->get_option( 'forms.google_recaptcha_site_key' );
	}

	/**
	 * Get recaptcha secret key
	 */
	public function get_recaptcha_secret_key(): string {
		return Options::instance()->get_option( 'forms._google_recaptcha_secret_key' );
	}


	/**
	 * Set options
	 *
	 * @param array $options The options.
	 * @return array
	 * @throws \Exception If an error occurs.
	 */
	public function on_set_options( $options ) {
		// get google recaptcha site key and secret key.
		$google_recaptcha_site_key   = $options['google_recaptcha_site_key'] ?? '';
		$google_recaptcha_secret_key = $options['_google_recaptcha_secret_key'] ?? '';
		// check if google recaptcha site key and secret are valid.
		if ( empty( $google_recaptcha_site_key ) || empty( $google_recaptcha_secret_key ) ) {
			throw new \Exception( 'Google Recaptcha Site Key and Secret Key are required.' );
		}

		// invent a google recaptcha response.
		$google_recaptcha_response = 'fake-google-recaptcha-response';

		// build the google recaptcha verify url.
		$google_recaptcha_verify_url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . $google_recaptcha_secret_key . '&response=' . $google_recaptcha_response;
		// get the google recaptcha verify response.
		$google_recaptcha_verify_response = wp_remote_get( $google_recaptcha_verify_url );
		// check if google recaptcha verify response is valid.
		if ( is_wp_error( $google_recaptcha_verify_response ) ) {
			// add an error message.
			// phpcs:ignore
			throw new \Exception( __( 'An error occurred. Please try again.', 'static-snap' ) );
		}
		// get the google recaptcha verify body.
		$google_recaptcha_verify_body = wp_remote_retrieve_body( $google_recaptcha_verify_response );
		// decode the google recaptcha verify body.
		$google_recaptcha_verify_data = json_decode( $google_recaptcha_verify_body, true );
		// check if google recaptcha verify data is valid.
		if ( empty( $google_recaptcha_verify_data ) || ! is_array( $google_recaptcha_verify_data ) ) {
			// add an error message.
			// phpcs:ignore
			throw new \Exception( __( 'An error occurred. Please try again.', 'static-snap' ) );
		}

		if ( isset( $google_recaptcha_verify_data['error-codes'] ) && in_array( 'invalid-input-response', $google_recaptcha_verify_data['error-codes'], true ) ) {
			return $options; // secret key is valid.
		}
		// phpcs:ignore
		throw new \Exception( __( 'Google Recaptcha Site Key and Secret Key are invalid.', 'static-snap' ) );
	}
}
