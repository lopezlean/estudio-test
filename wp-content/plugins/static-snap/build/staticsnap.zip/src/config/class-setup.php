<?php
/**
 * Setup
 *
 * @package StaticSnap
 */

namespace StaticSnap\Config;

const DEFAULT_ENVIRONMENTS = array(
	array(
		'id'       => 1,
		'order'    => 0,
		'name'     => 'Default',
		'type'     => 'file',
		'settings' => array(
			'path' => '{UPLOAD_DIR}/static-snap-build/{ENVIRONMENT_NAME}',
		),
		'valid'    => true,

	),
);

/**
 * Setup
 */
final class Setup {



	/**
	 * Run only once after plugin is activated
	 *
	 * @docs https://developer.wordpress.org/reference/functions/register_activation_hook/
	 */
	public static function activation() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		$options          = Options::instance();
		$database_options = $options->get_options();
		if ( empty( $database_options['environments'] ) ) {
			$options->set( 'environments', DEFAULT_ENVIRONMENTS );
			$options->save();
		}

		/**
		 * Use this to add a database table after the plugin is activated for example
		 */

		// Clear the permalinks.
		flush_rewrite_rules();
	}

	/**
	 * Run only once after plugin is deactivated
	 *
	 * @docs https://developer.wordpress.org/reference/functions/register_deactivation_hook/
	 */
	public static function deactivation() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		/**
		 * Use this to register a function which will be executed when the plugin is deactivated
		 */

		// Clear the permalinks.
		flush_rewrite_rules();

		// Uncomment the following line to see the function in action
		// exit( var_dump( $_GET ) );.
	}

	/**
	 * Run only once after plugin is uninstalled
	 *
	 * @docs https://developer.wordpress.org/reference/functions/register_uninstall_hook/
	 */
	public static function uninstall() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		/**
		 * Use this to remove plugin data and residues after the plugin is uninstalled for example
		 */

		// Uncomment the following line to see the function in action.
		// exit( var_dump( $_GET ) );.
	}
}
