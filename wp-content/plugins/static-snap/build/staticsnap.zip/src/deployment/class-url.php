<?php
/**
 * Interface  URL
 *
 * @package StaticSnap
 */

namespace StaticSnap\Deployment;

use StaticSnap\Interfaces\Deployment_URL_Interface;

/**
 * Interface URL defines the methods that a URL object should implement.
 */
// phpcs:ignore
class URL implements Deployment_URL_Interface {
	/**
	 * URL
	 *
	 * @var string $url
	 */
	private $url = null;

	/**
	 * Last modified
	 * we use string to compatibility with WordPress post object.
	 *
	 * @var string $last_modified
	 */
	private $last_modified = null;

	/**
	 * URL
	 *
	 * @var string $status
	 */
	private $status = null;

	/**
	 * Source
	 *
	 * @var string $source
	 */
	protected $source = 'Url::class';

	/**
	 * Priority
	 *
	 * @var int $priority
	 */
	protected $priority = 10;


	/**
	 * Constructor
	 *
	 * @param string $url URL.
	 * @param string $last_modified Last modified.
	 * @param string $status Status.
	 * @param string $source Source.
	 */
	public function __construct( string $url, string $last_modified = null, string $status = 'published', string $source = 'Url::class' ) {
		$this->url           = $url;
		$this->last_modified = $last_modified ? $last_modified : current_time( 'mysql' );
		$this->status        = $status;
		$this->source        = $source;
	}


	/**
	 * Get  priority
	 *
	 * @return int
	 */
	public function get_priority(): int {
		return $this->priority;
	}
	/**
	 * Set priority
	 *
	 * @param int $priority Priority.
	 * @return void
	 */
	public function set_priority( int $priority ) {
		$this->priority = $priority;
	}

	/**
	 * Get source
	 * Source is where the url is generated from.
	 */
	public function get_source(): string {
		return $this->source;
	}

	/**
	 * Set source
	 *
	 * @param string $source Source.
	 */
	public function set_source( string $source ) {
		$this->source = $source;
	}

	/**
	 * Get  URL
	 *
	 * @return string
	 */
	public function get_url(): string {
		return $this->url;
	}



	/**
	 * Get url hash
	 *
	 * @return string
	 */
	public function get_url_hash(): string {
		return md5( $this->get_url() );
	}

	/**
	 * Get local path
	 *
	 * @return string | null
	 */
	public function get_local_path() {
		return null;
	}

	/**
	 * Get last modified
	 *
	 * @return string
	 */
	public function get_last_modified(): string {
		return $this->last_modified;
	}

	/**
	 * Get status
	 *
	 * @return string
	 */
	public function get_status(): string {
		return $this->status;
	}

	/**
	 * To array
	 *
	 * @return array
	 */
	public function to_array(): array {
		return array(
			'url'           => $this->get_url(),
			'url_hash'      => $this->get_url_hash(),
			'last_modified' => $this->get_last_modified(),
			'status'        => $this->get_status(),
		);
	}

	/**
	 *
	 * Is valid url
	 * Valid url will be saved to the database by the deployment task.
	 * Invalid urls will be ignored.
	 *
	 * @return bool
	 */
	public function is_valid(): bool {
		$url   = $this->get_url();
		$valid = filter_var( $url, FILTER_VALIDATE_URL );
		if ( $valid ) {
			// url should be in the same domain.
			// some plugins add external urls to the post permalink.
			$home_url = home_url();
			$valid    = ! empty( strval( $url ) ) && strpos( $url, $home_url ) === 0;
		}
		return $valid;
	}

	/**
	 * Get url type
	 *
	 * @return string
	 */
	public function get_type(): string {
		return 'url';
	}
	/**
	 * Get type reference id
	 *
	 * @return int | null
	 */
	public function get_type_reference_id() {
		return null;
	}
}
