<?php
/**
 * Get posts
 *
 * @package StaticSnap
 */

namespace StaticSnap\Deployment;

use StaticSnap\Constants\Filters;

/**
 * Get posts class
 */
final class Posts {
	/**
	 * Default post filters, we will ignore attachments.
	 */
	public static function default_post_filters(): void {
		add_filter(
			Filters::POST_TYPES,
			function ( $posts ) {
				unset( $posts['attachment'] );
				// elementor_library is a custom post type that is not public.
				unset( $posts['elementor_library'] );

				return $posts;
			}
		);
	}
}
