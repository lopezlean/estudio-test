<?php
/**
 * Feeds
 *
 * @package StaticSnap
 */

namespace StaticSnap\Deployment;

use DateTime;
use StaticSnap\Constants\Actions;
use StaticSnap\Constants\Filters;
use StaticSnap\Traits\Singleton;

/**
 * Feeds class
 * This class will generate feeds url for each post / taxonomy / author
 */
final class Feeds {

	use Singleton;

	/**
	 * Init
	 */
	public function init() {
		// before save post urls we add the post feeds and root feeds.
		add_filter( Filters::BEFORE_SAVE_POST_URLS, array( $this, 'get_post_feeds' ) );
		add_filter( Filters::BEFORE_SAVE_TERM_URLS, array( $this, 'get_taxonomy_feeds' ) );
	}

	/**
	 * Get post feeds
	 *
	 * @param array $urls URLs.
	 * @return array
	 */
	public function get_post_feeds( array $urls ): array {
		$root_feeds = $this->get_root_feeds();
		$feeds_urls = array();

		foreach ( $urls as $url ) {
			$feeds = array();
			// check url instance is Post_URL.
			if ( ! $url instanceof Post_URL ) {
				continue;
			}
			$post    = $url->get_post();
			$feeds[] = get_post_comments_feed_link( $post->ID );
			$feeds[] = get_post_comments_feed_link( $post->ID, 'rss2' );
			$feeds[] = get_post_comments_feed_link( $post->ID, 'atom' );
			$feeds[] = get_post_comments_feed_link( $post->ID, 'rdf' );
			foreach ( $feeds as $feed ) {
				$feed_url = new URL( $feed, $url->get_last_modified(), $url->get_status(), 'Feeds::get_post_feeds' );
				// We need the feeds to be indexed first, because we will replace all the urls in the feeds with the local urls.
				$feed_url->set_priority( 1 );
				if ( $feed_url->is_valid() ) {
					$feeds_urls[] = $feed_url;
				}
			}
		}
		// add post feeds to the urls.
		return array_merge( $urls, $feeds_urls, $root_feeds );
	}

	/**
	 * Get Root feeds
	 *
	 * @return array
	 */
	public static function get_root_feeds(): array {
		$feeds = array();

		$feeds[] = get_bloginfo( 'rss2_url' );
		$feeds[] = get_bloginfo( 'atom_url' );
		$feeds[] = get_bloginfo( 'rdf_url' );
		$feeds[] = get_bloginfo( 'rss_url' );

		$feeds[] = get_bloginfo( 'comments_rss2_url' );
		$feeds[] = get_bloginfo( 'comments_atom_url' );

		$home_page_type = get_option( 'show_on_front' ) || 'posts';

		$home_post             = get_post( get_option( 'page' === $home_page_type ? 'page_on_front' : 'page_for_posts' ) );
		$home_post_date_string = gmdate( 'Y-m-d H:i:s', strtotime( 'now' ) );
		if ( ! empty( $home_post ) ) {
			$home_post_date_string = $home_post->post_modified;
		}

		$urls = array();
		foreach ( $feeds as $feed ) {
			$feed_url = new URL( $feed, $home_post_date_string, 'published', 'Feeds::get_root_feeds' );
			$feed_url->set_priority( 1 );
			if ( $feed_url->is_valid() ) {
				$urls[] = $feed_url;
			}
		}

		return $urls;
	}

	/**
	 * Get taxonomy feeds
	 *
	 * @param array $urls URLs.
	 * @return array
	 */
	public static function get_taxonomy_feeds( array $urls ): array {
		$feeds_urls = $urls;
		foreach ( $urls as $url ) {
			if ( ! $url instanceof Term_URL ) {
				continue;
			}
			$term    = $url->get_term();
			$feeds   = array();
			$feeds[] = get_term_feed_link( $term->term_id, $term->taxonomy );
			$feeds[] = get_term_feed_link( $term->term_id, $term->taxonomy, 'rss2' );
			$feeds[] = get_term_feed_link( $term->term_id, $term->taxonomy, 'atom' );
			$feeds[] = get_term_feed_link( $term->term_id, $term->taxonomy, 'rdf' );
			foreach ( $feeds as $feed ) {
				$feed_url = new URL( $feed, $url->get_last_modified(), $url->get_status(), 'Feeds::get_taxonomy_feeds' );
				// We need the feeds to be indexed first, because we will replace all the urls in the feeds with the local urls.
				$feed_url->set_priority( 1 );
				if ( $feed_url->is_valid() ) {
					$feeds_urls[] = $feed_url;
				}
			}
		}

		return $feeds_urls;
	}
}
