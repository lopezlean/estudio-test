<?php
/**
 * Class Post URL
 *
 * @package StaticSnap
 */

namespace StaticSnap\Deployment;

use StaticSnap\Constants\Filters;
use StaticSnap\Constants\Mimetypes;
use StaticSnap\Database\Replacements_URLS_Database;

/**
 * Post URL class
 */
final class Post_URL extends URL {
	/**
	 * Replacements
	 *
	 * @var array $url_replacements index the url to replace with the new url.
	 */
	private static $url_replacements = array();
	/**
	 * Post URL
	 *
	 * @var \WP_Post $post
	 */
	private $post;


	/**
	 * Constructor
	 *
	 * @param \WP_Post $post Post URL.
	 * @param string   $source Source.
	 */
	public function __construct( \WP_Post $post, $source = 'Post_URL::class' ) {
		$this->post = $post;
		$this->set_source( $source );
	}


	/**
	 * Get priority
	 *
	 * @return int
	 */
	public function get_priority(): int {
		return 10;
	}

	/**
	 * Get post URL
	 *
	 * @return string
	 */
	public function get_url(): string {
		switch ( $this->post->post_type ) {
			case 'page':
				return get_page_link( $this->post->ID );
			case 'attachment':
				return wp_get_attachment_url( $this->post->ID );

		}
		return get_permalink( $this->post->ID );
	}



	/**
	 * Get last modified
	 *
	 * @return string
	 */
	public function get_last_modified(): string {

		return $this->post->post_modified;
	}

	/**
	 * Get status
	 *
	 * @return string
	 */
	public function get_status(): string {
		return $this->post->post_status;
	}



	/**
	 * Get url content
	 *
	 * @return array
	 */
	public function get_content(): array {

		return $this->get_remote_url( '', $this->get_url() );
	}


	/**
	 * Default content filter
	 * will convert all site url to relative paths
	 *
	 * @param string $content Content.
	 *
	 * @return string
	 */
	public static function default_content_filter( string $content ): string {

		foreach ( self::$url_replacements as $url => $local_url ) {
			$content = str_replace( $url, $local_url, $content );           // replace the escaped version of the url.
		}
		/**
		 * Default content filter will replace all site urls with relative paths.
		 */
		$home_url = home_url( '/' );
		$content  = str_replace( $home_url, '/', $content );
		$content  = str_replace( rtrim( $home_url, '/' ), '/', $content );

		// some plugins like elementor encodes urls in elementorConfig object.
		$escaped_home_url = wp_json_encode( $home_url );
		// remove quotes with regex.
		$escaped_home_url = preg_replace( '/[\'"]/', '', $escaped_home_url );

		$content = str_replace( $escaped_home_url, '/', $content );
		return $content;
	}

	/**
	 * Add default filter
	 */
	public static function add_default_filter() {
		add_filter( Filters::POST_URL_CONTENT, array( __CLASS__, 'default_content_filter' ), 10, 1 );
	}
	/**
	 * Get remote url
	 *
	 * @param string $destination Destination.
	 * @param string $url URL.
	 *
	 * @return array [content, extension]
	 */
	public static function get_remote_url( string $destination, string $url ): array {
		$args = array(
			'redirection' => false,
			'blocking'    => true,
			'sslverify'   => false,
			'timeout'     => 10,
			'user-agent'  => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',

		);
		$args   = apply_filters( Filters::POST_URL_REMOTE_ARGS, $args, $url );
		$remote = wp_remote_get( $url, $args );

		if ( is_wp_error( $remote ) ) {
			new \WP_Error( 'error', 'Could not fetch url: ' . esc_html( $url ) );
		}

		// detect 301 redirect.
		$redirect_url = wp_remote_retrieve_header( $remote, 'location' );

		if ( $redirect_url ) {
			// content will have a redirect script
			// that will redirect to the new url.
			$redirect_url = apply_filters( Filters::POST_URL_CONTENT, $redirect_url );
			ob_start();
			include __DIR__ . '/templates/redirect.php';
			$content = ob_get_clean();
			return array( $content, 'html' );
		}

		$content_type = trim( wp_remote_retrieve_header( $remote, 'content-type' ) );

				// we want only the type part.
		if ( ! empty( strval( $content_type ) ) && false !== strpos( $content_type, ';' ) ) {
			$content_type = explode( ';', $content_type );
			$content_type = $content_type[0];
		}

		/**
		 * If the content type is not html, we will not save it.
		 */
		$extension = 'html';

		if ( 'text/html' !== $content_type ) {
			$assigned_extension = Mimetypes::get_extension( $content_type );
			if ( $assigned_extension ) {
				$extension = $assigned_extension[0];
			}
			$local_path 			   = self::get_file_local_destination( $destination, $url, $extension );
			$local_path_to_url         = str_replace( rtrim( $destination, DIRECTORY_SEPARATOR ), home_url(), $local_path );
			$url_replacements_database = Replacements_URLS_Database::instance();
			$url_replacements_database->insert( new URL_Replacement( $url, $local_path_to_url ) );
			self::$url_replacements[ $url ] = $local_path_to_url;

		}

		$content = wp_remote_retrieve_body( $remote );

		$content = apply_filters( Filters::POST_URL_CONTENT, $content, $url );

		return array( $content, $extension );
	}

	/**
	 * Get local destination
	 * Returns the local destination for the url in uploads directory.
	 *
	 * @param string $url URL.
	 * @param string $destination Destination.
	 * @return array
	 * @throws \Exception If the directory could not be created.
	 */
	public static function save_url( $url, $destination ): array {

		$directory_created = wp_mkdir_p( $destination );
		if ( false === $directory_created ) {
			throw new \Exception( 'Could not create directory: ' . esc_html( $destination ) );
		}

		[$content, $extension] = self::get_remote_url( $destination, $url );

		$local_path = self::get_file_local_destination( $destination, $url, $extension );

		global $wp_filesystem;

		if ( ! $wp_filesystem ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}
		wp_mkdir_p( dirname( $local_path ) );
		$bytes = $wp_filesystem->put_contents( $local_path, $content );

		return array(
			'saved'                  => false !== $bytes,
			'local_path_destination' => $local_path,
		);
	}



		/**
		 * Get file local destination.
		 * example http://localhost/test-url/ will be saved to
		 * /var/www/html/wp-content/uploads/static-snap/tmp/test-url/index.html
		 *
		 * @param string $destination Destination.
		 * @param string $url URL.
		 * @param string $extension Extension.
		 */
	public static function get_file_local_destination( $destination, $url, $extension ): string {
		$relative_path = wp_parse_url( $url, PHP_URL_PATH );
		$local_path    = trailingslashit( $destination ) . trailingslashit( $relative_path ) . 'index.' . $extension;
		$local_path    = apply_filters( 'static_snap_post_url_local_destination', $local_path, $url );

		$local_path = wp_normalize_path( $local_path );
		return $local_path;
	}


	/**
	 * Get post object
	 * Returns the post object.
	 *
	 * @return object
	 */
	public function get_post(): object {
		return $this->post;
	}

	/**
	 * Get url type
	 *
	 * @return string
	 */
	public function get_type(): string {
		return 'post';
	}

	/**
	 * Get type reference id
	 *
	 * @return int | null
	 */
	public function get_type_reference_id() {
		return $this->post->ID;
	}
}
