<?php
/**
 * Extensions Bootstrap File
 *
 * @package StaticSnap
 */

namespace StaticSnap\Extensions;

use StaticSnap\Constants\Actions;

use StaticSnap\Extension\Search\FuseJS\Fuse_JS_Search_Extension;
use StaticSnap\Extension\Search\Algolia\Algolia_Extension;
use StaticSnap\Extension\Forms\Elementor\Elementor_Form_Extension;
use StaticSnap\Extension\Forms\Contact_Form_7\Contact_Form_7_Extension;


$extensions = array(
	Fuse_JS_Search_Extension::class,
	Algolia_Extension::class,
	Elementor_Form_Extension::class,
	Contact_Form_7_Extension::class,

);



add_action(
	Actions::DEPLOYMENT_PROCESS_INIT_INTEGRATIONS,
	function () use ( $extensions ) {

		foreach ( $extensions as $extension ) {
			new $extension();
		}
	},
);
