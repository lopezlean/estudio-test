<?php
/**
 * Elementor Form Extension
 *
 * @package StaticSnap
 */

namespace StaticSnap\Extension\Forms\Elementor;

use StaticSnap\Forms\Form_Extension_Base;
use StaticSnap\Application;
use StaticSnap\Connect\Connect;
use StaticSnap\Constants\Recaptcha;

/**
 * Elementor Form Extension
 */
final class Elementor_Form_Extension extends Form_Extension_Base {

	private const TOKEN_FIELD_NAME = 'static_snap_website_token';
	private const TOKEN_FIELD_ID   = 'static-snap-website-token';

	private const FORM_NAME_FIELD_NAME = 'static_snap_form_name';
	private const FORM_NAME_FIELD_ID   = 'static-snap-form-name';

	private const FORM_ID_FIELD_NAME = 'static_snap_form_id';
	private const FORM_ID_FIELD_ID   = 'static-snap-form-id';

	private const FORM_TYPE_FIELD_NAME = 'static_snap_form_type';
	private const FORM_TYPE_FIELD_ID   = 'static-snap-form-type';

	/**
	 * Constructor
	 *
	 * @param array $params Parameters.
	 */
	public function __construct( $params = array() ) {
		parent::__construct( $params );
		if ( ! is_plugin_active( 'elementor-pro/elementor-pro.php' ) ) {
			return;
		}

		// add elementor-form.js to the footer on frontend.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ), 10 );
		// add action for form pre-render.
		add_action( 'elementor-pro/forms/pre_render', array( $this, 'update_action' ), 90, 2 );
		// before render.
		add_action( 'elementor/widget/before_render_content', array( $this, 'before_render' ), 10, 1 );
		add_filter( 'elementor_pro/forms/render/item', array( $this, 'filter_static_snap_input_name' ), 10, 3 );
	}

	/**
	 * Filter static snap input name
	 *
	 * @param array                                    $item       The field value.
	 * @param int                                      $item_index The field index.
	 * @param \ElementorPro\Modules\Forms\Widgets\Form $form       An instance of the form.
	 */
	public function filter_static_snap_input_name( $item, $item_index, $form ) {
		$fields = array(
			self::TOKEN_FIELD_ID,
			self::FORM_NAME_FIELD_ID,
			self::FORM_ID_FIELD_ID,
			self::FORM_TYPE_FIELD_ID,
		);
		$names  = array(
			self::TOKEN_FIELD_NAME,
			self::FORM_NAME_FIELD_NAME,
			self::FORM_ID_FIELD_NAME,
			self::FORM_TYPE_FIELD_NAME,
		);

		if ( in_array( $item['_id'], $fields, true ) ) {
			// remove the old render attribute.
			$form->remove_render_attribute( 'input' . $item_index, 'name' );
			$form->add_render_attribute( 'input' . $item_index, 'name', $names[ array_search( $item['_id'], $fields, true ) ] );
		}

		return $item;
	}

	/**
	 * Before render
	 *
	 * @param \Elementor\Element_Base $element Element.
	 */
	public function before_render( $element ) {
		if ( 'form' === $element->get_name() ) {
			$settings = $element->get_settings();

			$settings['form_fields'][] = array(
				'_id'         => self::TOKEN_FIELD_ID,
				'field_type'  => 'hidden',
				'field_label' => self::TOKEN_FIELD_ID,
				'custom_id'   => self::TOKEN_FIELD_ID,
				'required'    => true,
				'field_value' => $this->get_website_token(),

			);
			$settings['form_fields'][] = array(
				'_id'         => self::FORM_NAME_FIELD_ID,
				'field_type'  => 'hidden',
				'field_label' => self::FORM_NAME_FIELD_ID,
				'custom_id'   => self::FORM_NAME_FIELD_ID,
				'required'    => true,
				'field_value' => $settings['form_name'] ?? '',
			);
			$settings['form_fields'][] = array(
				'_id'         => self::FORM_ID_FIELD_ID,
				'field_type'  => 'hidden',
				'field_label' => self::FORM_ID_FIELD_ID,
				'custom_id'   => self::FORM_ID_FIELD_ID,
				'required'    => true,
				'field_value' => $element->get_id() ?? '',
			);

			$settings['form_fields'][] = array(
				'_id'         => self::FORM_TYPE_FIELD_ID,
				'field_type'  => 'hidden',
				'field_label' => self::FORM_TYPE_FIELD_ID,
				'custom_id'   => self::FORM_TYPE_FIELD_ID,
				'required'    => true,
				'field_value' => $this->get_name(),
			);

			$element->set_settings( $settings );
		}
	}

	/**
	 * Update action
	 *
	 * @param array                                    $settings settings for display.
	 * @param \ElementorPro\Modules\Forms\Widgets\Form $form Form data.
	 */
	public function update_action( &$settings, $form ) {
		$form->add_render_attribute( 'form', 'static-snap-type', 'form' );
		$form->add_render_attribute( 'form', 'action', $this->get_action_url() );
	}

	/**
	 * Get name
	 */
	public function get_name(): string {
		return 'elementor-form';
	}

	/**
	 * Get Settings fields
	 */
	public function get_settings_fields(): array {
		return array(
			'elementor_form' => array(
				'type'    => 'text',
				'label'   => __( 'Elementor Form ID', 'static-snap' ),
				'default' => '',
			),
		);
	}
	/**
	 * Get type
	 */
	public function get_type(): string {
		return 'form';
	}

	/**
	 * Is configured
	 */
	public function is_configured(): bool {
		// phpcs:ignore
		// $elementor_form = $this->get_setting( 'elementor_form' );
		// phpcs:ignore
		// return ! empty( $elementor_form );
		return true;
	}

	/**
	 * Enqueue scripts
	 */
	public function enqueue_scripts() {
		// phpcs:ignore
		// $asset_file = include STATIC_SNAP_PLUGIN_DIR . ' / assets / js / elementor - form . asset . php';
		// phpcs:ignore
		// wp_enqueue_script( 'static - snap - elementor - form', STATIC_SNAP_PLUGIN_URL . ' / assets / js / elementor - form . js', $asset_file['dependencies'], $asset_file['version'], true );
		// phpcs:ignore
		// add https://www.google.com/recaptcha/api.js?render=reCAPTCHA_site_key
		wp_enqueue_script( 'google-recaptcha', 'https://www.google.com/recaptcha/api.js?render=' . Recaptcha::SITE_KEY, array(), '3', true );
		$asset_file = include STATIC_SNAP_PLUGIN_DIR . '/assets/js/form.asset.php';
		// dependencies will be recaptcha plus dependencies from asset file.
		$asset_dependencies   = $asset_file['dependencies'];
		$asset_dependencies[] = 'google-recaptcha';
		wp_enqueue_script( 'static-snap-form', STATIC_SNAP_PLUGIN_URL . '/assets/js/forms.js', $asset_dependencies, $asset_file['version'], true );
	}
}
