<?php
/**
 * Contact Form 7 Extension
 *
 * @package StaticSnap
 */

namespace StaticSnap\Extension\Forms\Contact_Form_7;

use StaticSnap\Forms\Form_Extension_Base;
use StaticSnap\Application;
use StaticSnap\Connect\Connect;

/**
 * Contact Form 7 Extension
 */
final class Contact_Form_7_Extension extends Form_Extension_Base {


	private const TOKEN_FIELD_NAME = 'static_snap_website_token';

	private const FORM_NAME_FIELD_NAME = 'static_snap_form_name';


	private const FORM_ID_FIELD_NAME = 'static_snap_form_id';

	private const FORM_TYPE_FIELD_NAME = 'static_snap_form_type';


	/**
	 * Constructor
	 *
	 * @param array $params Parameters.
	 */
	public function __construct( $params = array() ) {
		parent::__construct( $params );
		if ( ! is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) ) {
			return;
		}

		add_filter( 'wpcf7_load_js', '__return_false' );
		add_filter( 'wpcf7_form_action_url', array( $this, 'get_action_url' ), 10 );
		// add fields to the form.
		add_filter( 'wpcf7_form_additional_atts', array( $this, 'add_additional_attributes' ), 10, 1 );
		add_filter( 'wpcf7_form_hidden_fields', array( $this, 'add_hidden_fields' ), 10, 1 );
	}

	/**
	 * Add additional attributes
	 *
	 * @param array $atts Attributes.
	 */
	public function add_additional_attributes( $atts ) {
		$atts['static-snap-type'] = 'form';
		return $atts;
	}

	/**
	 * Add hidden fields
	 *
	 * @param array $fields Fields.
	 */
	public function add_hidden_fields( $fields ) {

		if ( ! class_exists( '\WPCF7_ContactForm' ) ) {
			return $fields;
		}

		$form = \WPCF7_ContactForm::get_current(); // phpcs:ignore

		$fields[ self::TOKEN_FIELD_NAME ]     = $this->get_website_token();
		$fields[ self::FORM_NAME_FIELD_NAME ] = $form->title();
		$fields[ self::FORM_ID_FIELD_NAME ]   = $form->id();

		$fields[ self::FORM_TYPE_FIELD_NAME ] = 'contact-form-7';
		return $fields;
	}

	/**
	 * Get name
	 */
	public function get_name(): string {
		return 'contact-form-7';
	}
}
