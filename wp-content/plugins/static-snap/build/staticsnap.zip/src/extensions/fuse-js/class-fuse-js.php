<?php
/**
 * Pagefind integration
 *
 * @package StaticSnap
 */

namespace StaticSnap\Extension\Search\FuseJS;

use StaticSnap\Constants\Filters;
use StaticSnap\Deployment\Deployment_Task_Manager;
use StaticSnap\Integrations\Fuse_JS\Tasks\Fuse_JS_Prepare_Task;
use StaticSnap\Integrations\Fuse_JS\Tasks\Fuse_JS_Task;


/**
 * Pagefind class
 */
final class Fuse_JS {

	/**
	 * Constructor
	 */
	public function __construct() {
		new Fuse_JS_Search_Extension();
	}



	/**
	 * Get search file name
	 *
	 * @return string
	 */
	public static function get_search_file_name() {
		return 'search.json';
	}

	/**
	 * Get search file path
	 *
	 * @param string $build_path Build path.
	 * @return string
	 */
	public static function get_search_file_path( $build_path ) {
		return $build_path . DIRECTORY_SEPARATOR . self::get_search_file_name();
	}

	/**
	 * Prepare search file
	 *
	 * @param string $build_path File path.
	 */
	public static function prepare_index( $build_path ) {
		$file_path = self::get_search_file_path( $build_path );
		if ( file_exists( $file_path ) ) {
			wp_delete_file( $file_path );
		}
		global $wp_filesystem;

		if ( ! $wp_filesystem ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}
		// recreate the file.
		$wp_filesystem->touch( $file_path );
	}


	/**
	 * Post to index
	 *
	 * @param \WP_Post $post Post object.
	 * @param string   $url URL.
	 * @return array
	 */
	public static function post_to_index( $post, $url = null ) {
		$content = wp_strip_all_tags( apply_filters( 'the_content', $post->post_content ) );
		$title   = wp_kses_post( $post->post_title );
		$excerpt = wp_strip_all_tags( self::get_the_excerpt( $post ) );

		$index = array(
			'id'      => $post->ID,
			'title'   => $title,
			'content' => $content,
			'excerpt' => $excerpt,
			'url'     => $url ? $url : get_permalink( $post->ID ),
		);

		return $index;
	}

	/**
	 * Index post
	 *
	 * @param array  $posts posts array.
	 * @param string $build_path build path.
	 */
	public static function index_posts( $posts, $build_path ) {
		global $wp_filesystem;

		$json_file = self::get_search_file_path( $build_path );

		if ( ! $wp_filesystem ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		// get all content from json_file.
		// phpcs:ignore
		$search_json        = $wp_filesystem->get_contents( $json_file );
		$all_indexed_items = json_decode( $search_json, true ) ?? array();

		$all_indexed_items = array_merge( $all_indexed_items, $posts );

		// append index to search.json.
		$index_json = wp_json_encode( $all_indexed_items );

		// recreate the file.
		$wp_filesystem->put_contents( $json_file, $index_json );
	}

		/**
		 * Get the excerpt
		 *
		 * @param object $post Post object.
		 * @return string
		 */
	public static function get_the_excerpt( $post ) {
		$text = get_the_excerpt( $post );

		if ( ! $text ) {
			$text = $post->post_content;
		}

		$generated_excerpt = wp_trim_words( $text, 55 );

		return apply_filters( 'get_the_excerpt', $generated_excerpt, $post );
	}
}
