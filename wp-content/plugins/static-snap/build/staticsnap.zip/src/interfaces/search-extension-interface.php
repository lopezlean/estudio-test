<?php
/**
 * Search Type Interface
 * This interface is used to create new serach type
 *
 * @package StaticSnap
 */

namespace StaticSnap\Interfaces;

interface Search_Extension_Interface extends Extension_Interface {


}
