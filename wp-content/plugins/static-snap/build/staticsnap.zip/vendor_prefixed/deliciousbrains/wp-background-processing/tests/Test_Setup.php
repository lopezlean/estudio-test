<?php

namespace StaticSnapVendor;

/**
 * Class Test_Setup
 *
 * @package WP-Background-Processing
 */
/**
 * Sample test case.
 */
class Test_Setup extends WP_UnitTestCase
{
    /**
     * Are unit tests set up correctly?
     */
    public function test_it_works()
    {
        $this->assertTrue(\true);
    }
}
/**
 * Class Test_Setup
 *
 * @package WP-Background-Processing
 */
/**
 * Sample test case.
 */
\class_alias('StaticSnapVendor\\Test_Setup', 'Test_Setup', \false);
