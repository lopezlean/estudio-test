<?php

namespace StaticSnapVendor;

class Test_Batch_Data
{
    public $prop = "value";
}
\class_alias('StaticSnapVendor\\Test_Batch_Data', 'Test_Batch_Data', \false);
