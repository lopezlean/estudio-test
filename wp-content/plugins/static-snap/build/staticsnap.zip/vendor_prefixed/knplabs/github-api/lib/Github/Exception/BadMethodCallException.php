<?php

namespace StaticSnapVendor\Github\Exception;

/**
 * @author James Brooks <jbrooksuk@me.com>
 */
class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
