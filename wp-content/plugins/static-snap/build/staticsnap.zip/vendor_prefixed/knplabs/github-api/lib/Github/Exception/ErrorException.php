<?php

namespace StaticSnapVendor\Github\Exception;

/**
 * @author Joseph Bielawski <stloyd@gmail.com>
 */
class ErrorException extends \ErrorException implements ExceptionInterface
{
}
