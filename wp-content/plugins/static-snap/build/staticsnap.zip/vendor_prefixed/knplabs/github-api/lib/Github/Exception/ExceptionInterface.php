<?php

namespace StaticSnapVendor\Github\Exception;

use StaticSnapVendor\Http\Client\Exception;
interface ExceptionInterface extends Exception
{
}
