<?php

namespace StaticSnapVendor\Algolia\AlgoliaSearch\Exceptions;

final class RetriableException extends RequestException
{
}
