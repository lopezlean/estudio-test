<?php

namespace StaticSnapVendor\Algolia\AlgoliaSearch\Exceptions;

final class ValidUntilNotFoundException extends AlgoliaException
{
}
