<?php

namespace StaticSnapVendor\Algolia\AlgoliaSearch\Exceptions;

class MissingObjectId extends AlgoliaException
{
}
