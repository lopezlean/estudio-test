<?php

namespace StaticSnapVendor\Algolia\AlgoliaSearch\Exceptions;

final class CannotWaitException extends AlgoliaException
{
}
