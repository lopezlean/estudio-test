<?php

namespace StaticSnapVendor\Algolia\AlgoliaSearch\Exceptions;

class BadRequestException extends RequestException
{
}
