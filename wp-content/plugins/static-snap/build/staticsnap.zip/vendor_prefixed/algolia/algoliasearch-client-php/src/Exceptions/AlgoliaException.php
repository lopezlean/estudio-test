<?php

namespace StaticSnapVendor\Algolia\AlgoliaSearch\Exceptions;

class AlgoliaException extends \Exception
{
}
