<?php

namespace StaticSnapVendor\Algolia\AlgoliaSearch\Exceptions;

final class NotFoundException extends BadRequestException
{
}
