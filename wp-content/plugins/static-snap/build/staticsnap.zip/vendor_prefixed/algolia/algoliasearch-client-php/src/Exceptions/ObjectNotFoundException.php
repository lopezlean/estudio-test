<?php

namespace StaticSnapVendor\Algolia\AlgoliaSearch\Exceptions;

final class ObjectNotFoundException extends AlgoliaException
{
}
