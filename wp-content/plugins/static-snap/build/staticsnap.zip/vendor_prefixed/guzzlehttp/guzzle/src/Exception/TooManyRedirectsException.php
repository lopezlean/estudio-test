<?php

namespace StaticSnapVendor\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}
