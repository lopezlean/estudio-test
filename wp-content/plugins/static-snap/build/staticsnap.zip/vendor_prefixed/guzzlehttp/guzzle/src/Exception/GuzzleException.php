<?php

namespace StaticSnapVendor\GuzzleHttp\Exception;

use StaticSnapVendor\Psr\Http\Client\ClientExceptionInterface;
interface GuzzleException extends ClientExceptionInterface
{
}
