<?php

namespace StaticSnapVendor\Http\Factory\Guzzle;

use StaticSnapVendor\GuzzleHttp\Psr7\Uri;
use StaticSnapVendor\Psr\Http\Message\UriFactoryInterface;
use StaticSnapVendor\Psr\Http\Message\UriInterface;
class UriFactory implements UriFactoryInterface
{
    public function createUri(string $uri = '') : UriInterface
    {
        return new Uri($uri);
    }
}
