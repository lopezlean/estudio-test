<?php

namespace StaticSnapVendor\Http\Factory\Guzzle;

use StaticSnapVendor\GuzzleHttp\Psr7\UploadedFile;
use StaticSnapVendor\Psr\Http\Message\UploadedFileFactoryInterface;
use StaticSnapVendor\Psr\Http\Message\StreamInterface;
use StaticSnapVendor\Psr\Http\Message\UploadedFileInterface;
class UploadedFileFactory implements UploadedFileFactoryInterface
{
    public function createUploadedFile(StreamInterface $stream, int $size = null, int $error = \UPLOAD_ERR_OK, string $clientFilename = null, string $clientMediaType = null) : UploadedFileInterface
    {
        if ($size === null) {
            $size = $stream->getSize();
        }
        return new UploadedFile($stream, $size, $error, $clientFilename, $clientMediaType);
    }
}
