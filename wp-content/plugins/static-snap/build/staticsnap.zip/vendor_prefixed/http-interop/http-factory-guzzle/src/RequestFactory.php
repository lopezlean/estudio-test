<?php

namespace StaticSnapVendor\Http\Factory\Guzzle;

use StaticSnapVendor\GuzzleHttp\Psr7\Request;
use StaticSnapVendor\Psr\Http\Message\RequestFactoryInterface;
use StaticSnapVendor\Psr\Http\Message\RequestInterface;
class RequestFactory implements RequestFactoryInterface
{
    public function createRequest(string $method, $uri) : RequestInterface
    {
        return new Request($method, $uri);
    }
}
