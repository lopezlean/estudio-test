<?php

declare (strict_types=1);
namespace StaticSnapVendor\Http\Client\Common;

use StaticSnapVendor\Http\Client\Common\HttpClientPool\HttpClientPoolItem;
use StaticSnapVendor\Http\Client\HttpAsyncClient;
use StaticSnapVendor\Http\Client\HttpClient;
use StaticSnapVendor\Psr\Http\Client\ClientInterface;
/**
 * A http client pool allows to send requests on a pool of different http client using a specific strategy (least used,
 * round robin, ...).
 */
interface HttpClientPool extends HttpAsyncClient, HttpClient
{
    /**
     * Add a client to the pool.
     *
     * @param ClientInterface|HttpAsyncClient|HttpClientPoolItem $client
     */
    public function addHttpClient($client) : void;
}
