<?php return array('dependencies' => array('lodash', 'react', 'react-dom', 'wp-api-fetch', 'wp-i18n'), 'version' => 'c3cfd5e2fda5fea03f23');
