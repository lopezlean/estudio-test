<?php return array('dependencies' => array('wp-i18n'), 'version' => '443b997e76cb589d07e4');
