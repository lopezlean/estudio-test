<?php return array('dependencies' => array(), 'version' => '04204339ba0a98d1f94a');
