<?php return array('dependencies' => array(), 'version' => 'b0164f455d1ff58e2b24');
