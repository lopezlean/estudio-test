<?php
/**
 * Static Snap
 *
 * @package   StaticSnap
 * @author    Leandro Emanuel Lopez <leandro@ligrila.com>
 * @copyright 2024 Leandro Emanuel Lopez
 * @license   MIT
 * @link      https://staticsnap.com
 *
 * Plugin Name:     Static Snap
 * Plugin URI:      https://staticsnap.com
 * Description:     Static Snap transforms WordPress into a powerful tool for creating static websites.
 * Version:         1.0.0
 * Author:          Leandro Emanuel Lopez
 * Author URI:      https://staticsnap.com
 * Text Domain:     static-snap
 * Domain Path:     /languages
 * Requires PHP:    7.4
 * Requires WP:     6.5.0
 * Namespace:       StaticSnap
 */

declare(strict_types=1);


/**
 * Define the default root file of the plugin
 *
 * @since 1.0.0
 */
define( 'STATIC_SNAP_PLUGIN_FILE', __FILE__ );
define( 'STATIC_SNAP_PLUGIN_DIR', __DIR__ );
define( 'STATIC_SNAP_PLUGIN_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );

/**
 * Load PSR4 autoloader
 *
 * @since 1.0.0
 */
$staticsnap_autoloader = require plugin_dir_path( STATIC_SNAP_PLUGIN_FILE ) . 'vendor/autoload.php';

/**
 * Setup hooks (activation, deactivation, uninstall)
 *
 * @since 1.0.0
 */
register_activation_hook( __FILE__, array( 'StaticSnap\Config\Setup', 'activation' ) );
register_deactivation_hook( __FILE__, array( 'StaticSnap\Config\Setup', 'deactivation' ) );
register_uninstall_hook( __FILE__, array( 'StaticSnap\Config\Setup', 'uninstall' ) );

/**
 * Bootstrap the plugin
 *
 * @since 1.0.0
 */
if ( ! class_exists( '\StaticSnap\Bootstrap' ) ) {
	wp_die( esc_html__( 'Static Snap is unable to find the Bootstrap class.', 'static-snap' ) );
}
add_action(
	'plugins_loaded',
	static function () use ( $staticsnap_autoloader ) {
		/**
		 * Bootstrap the plugin
		 *
		 * @see \StaticSnap\Bootstrap
		 */
		try {
			load_plugin_textdomain( 'static-snap', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
			new \StaticSnap\Bootstrap( $staticsnap_autoloader );
		} catch ( Exception $e ) {
			wp_die( esc_html__( 'Static Snap is unable to run the Bootstrap class.', 'static-snap' ) );
		}
	},
	1
);
